---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

Please describe the desired feature/behaviour.

Supporting images/mockups, or example reference videos are very helpful to communicate ideas.
